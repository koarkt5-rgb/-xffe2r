package com.example.oxidelauncher;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

import com.topjohnwu.superuser.Shell;

public class MainActivity extends Activity {

    // Подключаем C++ инжектор (который мы вшиваем в APK)
    static {
        System.loadLibrary("injector"); 
    }

    // Нативная функция из C++
    public native boolean injectLibrary(int pid, String libPath);

    private String pluginPath = null;
    private TextView btnAddPlugin;
    private TextView btnLaunch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAddPlugin = findViewById(R.id.btnAddPlugin);
        btnLaunch = findViewById(R.id.btnLaunch);

        // Запрос Root прав
        Shell.getShell(shell -> {
            if (!shell.isRoot()) {
                runOnUiThread(() -> Toast.makeText(this, "Нет ROOT! Инжект не сработает.", Toast.LENGTH_LONG).show());
            }
        });

        // Кнопка выбора плагина
        btnAddPlugin.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            startActivityForResult(i, 100);
        });

        // Кнопка ЗАПУСТИТЬ ИГРУ
        btnLaunch.setOnClickListener(v -> {
            if (pluginPath == null) {
                Toast.makeText(this, "Сначала выбери .so плагин!", Toast.LENGTH_SHORT).show();
                return;
            }
            // Запускаем Oxide (пакет игры)
            new Thread(() -> doInject("com.catsbit.oxidesurvivalisland", pluginPath)).start();
        });
    }

    // Получение пути к выбранному .so файлу
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 100 && res == RESULT_OK && data != null) {
            try {
                InputStream in = getContentResolver().openInputStream(data.getData());
                File out = new File(getCacheDir(), "plugin.so");
                FileOutputStream fos = new FileOutputStream(out);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
                fos.close(); in.close();
                
                pluginPath = out.getAbsolutePath();
                Toast.makeText(this, "Плагин выбран!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    // Логика запуска и инжекта
    private void doInject(String pkg, String localSo) {
        Shell.cmd("monkey -p " + pkg + " 1").exec(); // Запускаем игру

        int pid = -1;
        long startTime = System.currentTimeMillis();
        
        // Ждем до 15 секунд появления процесса игры
        while (System.currentTimeMillis() - startTime < 15000) {
            List<String> out = Shell.cmd("pidof " + pkg).exec().getOut();
            if (!out.isEmpty()) {
                pid = Integer.parseInt(out.get(0).trim().split(" ")[0]);
                break;
            }
            try { Thread.sleep(300); } catch (Exception ignored) {}
        }

        if (pid == -1) {
            runOnUiThread(() -> Toast.makeText(this, "Игра не запустилась", Toast.LENGTH_LONG).show());
            return;
        }

        // Копируем .so и даем права
        Shell.cmd("cp " + localSo + " /data/local/tmp/mod.so").exec();
        Shell.cmd("chmod 755 /data/local/tmp/mod.so").exec();

        // Вызываем инжект
        boolean ok = injectLibrary(pid, "/data/local/tmp/mod.so");
        runOnUiThread(() -> Toast.makeText(this, ok ? "Инжект OK!" : "Инжект провален", Toast.LENGTH_LONG).show());
    }
}